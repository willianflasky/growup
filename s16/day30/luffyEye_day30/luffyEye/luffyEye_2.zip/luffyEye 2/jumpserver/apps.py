from django.apps import AppConfig


class JumpserverConfig(AppConfig):
    name = 'jumpserver'
